//
//  global_param.cpp
//  VINS_ios
//
//  Created by HKUST Aerial Robotics on 2017/05/09.
//  Copyright © 2017 HKUST Aerial Robotics. All rights reserved.
//

#include <stdio.h>
#include "global_param.hpp"

double FOCUS_LENGTH_Y;
double PY;
double FOCUS_LENGTH_X;
double PX;
double SOLVER_TIME;
int FREQ;

//extrinsic param
double TIC_X;
double TIC_Y;
double TIC_Z;

bool setGlobalParam(DeviceType device)
{
    switch (device) {
        case iPhone7P:
            printf("Device iPhone7 plus param\n");
            FOCUS_LENGTH_X = 526.600;
            FOCUS_LENGTH_Y = 526.678;
            PX = 243.481;
            PY = 315.280;
            
            SOLVER_TIME = 0.06;
            FREQ = 3;
            
            TIC_X = 0.0;
            TIC_Y = 0.092;
            TIC_Z = 0.01;
            return true;
            break;

        case GalaxyS10e:
            printf("Device GalaxyS7 param\n");
            FOCUS_LENGTH_X = 515.0000;
            FOCUS_LENGTH_Y = 515.0000;
            PX = 240.0000, PY = 320.0000;

            SOLVER_TIME = 1.0; // 0.06
            FREQ = 3;

            TIC_X = 0.0; // view direction
            TIC_Y = -0.0023;
            TIC_Z = 0.0261;
            return true;
            break;

        case LGV60:
            printf("Device LGV60 param\n");
            FOCUS_LENGTH_X = 506.0000;//504.91
            FOCUS_LENGTH_Y = 506.0000;//507.74
            PX = 240.0000;//239.81
            PY = 320.0000;//319.38

            SOLVER_TIME = 1.0; // 0.06
            FREQ = 3;

            TIC_X = 0.0;
            TIC_Y = 0.005;
            TIC_Z = 0.038;
            return true;
            break;

        case unDefine:
            return false;
            break;
        default:
            return false;
            break;
    }
}





